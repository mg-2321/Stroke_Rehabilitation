% Remove rows with missing values
Data = prestrokeEEG(~any(ismissing(prestrokeEEG), 2), :);
Data2 = poststrokeEEG(~any(ismissing(poststrokeEEG), 2), :);

% Convert the 'Comment' column to a string array
Data.Comments = string(Data.Comments);

% Separate the dataset into four matrices by Comments
Rest_data = Data(strcmp(Data.Comments, 'Rest'), :);
HandWave_data = Data(strcmp(Data.Comments, 'Hand Wave'), :);
FaceRub_data = Data(strcmp(Data.Comments, 'Face Rub'), :);
HandClench_data = Data(strcmp(Data.Comments, 'Hand Clench'), :);

% Features to compute statistics for
features = {'LE', 'F4', 'C4', 'P4', 'P3', 'C3', 'F3'};

% Create a new figure for all the plots
figure;

% Add a main title for the entire figure
sgtitle('Normal Distributions for the EEG Pre-Stroke');

% Loop through features and compute statistics for each Comment
for i = 1:length(features)
    feature = features{i};
    
    % For Rest
    Rest_feature = Rest_data.(feature);
    mean_Rest = mean(Rest_feature);
    var_Rest = var(Rest_feature);
    
    % For Hand Wave
    HandWave_feature = HandWave_data.(feature);
    mean_HandWave = mean(HandWave_feature);
    var_HandWave = var(HandWave_feature);
    
    % For Face Rub
    FaceRub_feature = FaceRub_data.(feature);
    mean_FaceRub = mean(FaceRub_feature);
    var_FaceRub = var(FaceRub_feature);
    
    % For Hand Clench
    HandClench_feature = HandClench_data.(feature);
    mean_HandClench = mean(HandClench_feature);
    var_HandClench = var(HandClench_feature);
    
    % Display statistics for the current feature
    fprintf('\n\n--- %s ---\n', feature);
    fprintf('\nRest: Mean = %.4f, Variance = %.6f\n', mean_Rest, var_Rest);
    fprintf('Hand Wave: Mean = %.4f, Variance = %.6f\n', mean_HandWave, var_HandWave);
    fprintf('Face Rub: Mean = %.4f, Variance = %.6f\n', mean_FaceRub, var_FaceRub);
    fprintf('Hand Clench: Mean = %.4f, Variance = %.6f\n', mean_HandClench, var_HandClench);

    % Select a subplot for the current feature
    subplot(ceil(length(features)/2), 2, i); % Arrange in a grid (e.g., 2 columns)
    
    % Rest Density Plot
    x_Rest = linspace(mean_Rest - 3*sqrt(var_Rest), mean_Rest + 3*sqrt(var_Rest), 100);
    y_Rest = normpdf(x_Rest, mean_Rest, sqrt(var_Rest));
    plot(x_Rest, y_Rest, 'r', 'LineWidth', 2); hold on;
    
    % Hand Wave Density Plot
    x_HandWave = linspace(mean_HandWave - 3*sqrt(var_HandWave), mean_HandWave + 3*sqrt(var_HandWave), 100);
    y_HandWave = normpdf(x_HandWave, mean_HandWave, sqrt(var_HandWave));
    plot(x_HandWave, y_HandWave, 'g', 'LineWidth', 2);
    
    % Face Rub Density Plot
    x_FaceRub = linspace(mean_FaceRub - 3*sqrt(var_FaceRub), mean_FaceRub + 3*sqrt(var_FaceRub), 100);
    y_FaceRub = normpdf(x_FaceRub, mean_FaceRub, sqrt(var_FaceRub));
    plot(x_FaceRub, y_FaceRub, 'b', 'LineWidth', 2);
    
    % Hand Clench Density Plot
    x_HandClench = linspace(mean_HandClench - 3*sqrt(var_HandClench), mean_HandClench + 3*sqrt(var_HandClench), 100);
    y_HandClench = normpdf(x_HandClench, mean_HandClench, sqrt(var_HandClench));
    plot(x_HandClench, y_HandClench, 'm', 'LineWidth', 2);
    
    % Add title, labels, and legend
    title([feature ' Normal Distributions']);
    xlabel([feature ' values']);
    ylabel('Density');
    legend('Rest', 'Hand Wave', 'Face Rub', 'Hand Clench');
    hold off;

end


%-----------------------------------------------------------------------------------------------


% Convert the 'Comment' column to a string array
Data2.Comments = string(Data2.Comments);

% Separate the dataset into four matrices by Comments
Rest_data2 = Data2(strcmp(Data2.Comments, 'Rest'), :);
HandWave_data2 = Data2(strcmp(Data2.Comments, 'Hand Wave'), :);
FaceRub_data2 = Data2(strcmp(Data2.Comments, 'Face Rub'), :);
HandClench_data2 = Data2(strcmp(Data2.Comments, 'Hand Clench'), :);

% Features to compute statistics for
features = {'LE', 'F4', 'C4', 'P4', 'P3', 'C3', 'F3'};

% Create a new figure for all the plots
figure;

% Add a main title for the entire figure
sgtitle('Normal Distributions for the EEG post-Stroke');

% Loop through features and compute statistics for each Comment
for i = 1:length(features)
    feature = features{i};
    
    % For Rest
    Rest_feature2 = Rest_data2.(feature);
    mean_Rest = mean(Rest_feature2);
    var_Rest = var(Rest_feature2);
    
    % For Hand Wave
    HandWave_feature2 = HandWave_data2.(feature);
    mean_HandWave = mean(HandWave_feature2);
    var_HandWave = var(HandWave_feature2);
    
    % For Face Rub
    FaceRub_feature2 = FaceRub_data2.(feature);
    mean_FaceRub = mean(FaceRub_feature2);
    var_FaceRub = var(FaceRub_feature2);
    
    % For Hand Clench
    HandClench_feature2 = HandClench_data2.(feature);
    mean_HandClench = mean(HandClench_feature2);
    var_HandClench = var(HandClench_feature2);
    
    % Display statistics for the current feature
    fprintf('\n\n--- %s ---\n', feature);
    fprintf('\nRest: Mean = %.4f, Variance = %.6f\n', mean_Rest, var_Rest);
    fprintf('Hand Wave: Mean = %.4f, Variance = %.6f\n', mean_HandWave, var_HandWave);
    fprintf('Face Rub: Mean = %.4f, Variance = %.6f\n', mean_FaceRub, var_FaceRub);
    fprintf('Hand Clench: Mean = %.4f, Variance = %.6f\n', mean_HandClench, var_HandClench);

    % Select a subplot for the current feature
    subplot(ceil(length(features)/2), 2, i); % Arrange in a grid (e.g., 2 columns)
    
    % Rest Density Plot
    x_Rest = linspace(mean_Rest - 3*sqrt(var_Rest), mean_Rest + 3*sqrt(var_Rest), 100);
    y_Rest = normpdf(x_Rest, mean_Rest, sqrt(var_Rest));
    plot(x_Rest, y_Rest, 'r', 'LineWidth', 2); hold on;
    
    % Hand Wave Density Plot
    x_HandWave = linspace(mean_HandWave - 3*sqrt(var_HandWave), mean_HandWave + 3*sqrt(var_HandWave), 100);
    y_HandWave = normpdf(x_HandWave, mean_HandWave, sqrt(var_HandWave));
    plot(x_HandWave, y_HandWave, 'g', 'LineWidth', 2);
    
    % Face Rub Density Plot
    x_FaceRub = linspace(mean_FaceRub - 3*sqrt(var_FaceRub), mean_FaceRub + 3*sqrt(var_FaceRub), 100);
    y_FaceRub = normpdf(x_FaceRub, mean_FaceRub, sqrt(var_FaceRub));
    plot(x_FaceRub, y_FaceRub, 'b', 'LineWidth', 2);
    
    % Hand Clench Density Plot
    x_HandClench = linspace(mean_HandClench - 3*sqrt(var_HandClench), mean_HandClench + 3*sqrt(var_HandClench), 100);
    y_HandClench = normpdf(x_HandClench, mean_HandClench, sqrt(var_HandClench));
    plot(x_HandClench, y_HandClench, 'm', 'LineWidth', 2);
    
    % Add title, labels, and legend
    title([feature ' Normal Distributions']);
    xlabel([feature ' values']);
    ylabel('Density');
    legend('Rest', 'Hand Wave', 'Face Rub', 'Hand Clench');
    hold off;

end