prestroke = readtable("ProfMatthew_(Arsheya_source)_Prestoke_Redo.csv");
poststroke = readtable("ProfMatthew_(Sunjil_source)_Poststoke_Redo.csv");

prestroke = rmmissing(prestroke); % this is all the data at once
poststroke = rmmissing(poststroke);

% Preprocess data; Remove "useless" fields
prestroke = removevars(prestroke, {'Time', 'Trigger', 'Time_Offset', 'ADC_Status', 'ADC_Sequence', 'Event'}); 
poststroke = removevars(poststroke, {'Time', 'Trigger', 'Time_Offset', 'ADC_Status', 'ADC_Sequence', 'Event'}); 

% Split datasets by class
pre_Rest = prestroke(find(prestroke.Comments=="Rest"), :);
pre_Wave = prestroke(find(prestroke.Comments=="Hand Wave"), :);
pre_Clench = prestroke(find(prestroke.Comments=="Hand Clench"), :);
pre_Rub = prestroke(find(prestroke.Comments=="Face Rub"), :);

post_Rest = poststroke(find(poststroke.Comments=="Rest"), :);
post_Wave = poststroke(find(poststroke.Comments=="Hand Wave"), :);
post_Clench = poststroke(find(poststroke.Comments=="Hand Clench"), :);
post_Rub = poststroke(find(poststroke.Comments=="Face Rub"), :);

% Compute correlation matrices for pre-stroke categories
corr_pre_Rest = corr(table2array(removevars(pre_Rest, "Comments")));
corr_pre_Wave = corr(table2array(removevars(pre_Wave, "Comments")));
corr_pre_Clench = corr(table2array(removevars(pre_Clench, "Comments")));
corr_pre_Rub = corr(table2array(removevars(pre_Rub, "Comments")));

% Compute correlation matrices for post-stroke categories
corr_post_Rest = corr(table2array(removevars(post_Rest, "Comments")));
corr_post_Wave = corr(table2array(removevars(post_Wave, "Comments")));
corr_post_Clench = corr(table2array(removevars(post_Clench, "Comments")));
corr_post_Rub = corr(table2array(removevars(post_Rub, "Comments")));

% Pre-Stroke Rest vs Post-Stroke Rest
figure;
subplot(1, 2, 1);
heatmap(corr_pre_Rest, 'Title', 'Pre-Stroke Rest');
subplot(1, 2, 2);
heatmap(corr_post_Rest, 'Title', 'Post-Stroke Rest');

% Pre-Stroke Hand Wave vs Post-Stroke Hand Wave
figure;
subplot(1, 2, 1);
heatmap(corr_pre_Wave, 'Title', 'Pre-Stroke Hand Wave');
subplot(1, 2, 2);
heatmap(corr_post_Wave, 'Title', 'Post-Stroke Hand Wave');

% Pre-Stroke Hand Clench vs Post-Stroke Hand Clench
figure;
subplot(1, 2, 1);
heatmap(corr_pre_Clench, 'Title', 'Pre-Stroke Hand Clench');
subplot(1, 2, 2);
heatmap(corr_post_Clench, 'Title', 'Post-Stroke Hand Clench');

% Pre-Stroke Face Rub vs Post-Stroke Face Rub
figure;
subplot(1, 2, 1);
heatmap(corr_pre_Rub, 'Title', 'Pre-Stroke Face Rub');
subplot(1, 2, 2);
heatmap(corr_post_Rub, 'Title', 'Post-Stroke Face Rub');

% Compute covariance matrices for pre-stroke categories
cov_pre_Rest = cov(table2array(removevars(pre_Rest, "Comments")));
cov_pre_Wave = cov(table2array(removevars(pre_Wave, "Comments")));
cov_pre_Clench = cov(table2array(removevars(pre_Clench, "Comments")));
cov_pre_Rub = cov(table2array(removevars(pre_Rub, "Comments")));

% Compute covariance matrices for post-stroke categories
cov_post_Rest = cov(table2array(removevars(post_Rest, "Comments")));
cov_post_Wave = cov(table2array(removevars(post_Wave, "Comments")));
cov_post_Clench = cov(table2array(removevars(post_Clench, "Comments")));
cov_post_Rub = cov(table2array(removevars(post_Rub, "Comments")));

% Pre-Stroke Rest vs Post-Stroke Rest
figure;
subplot(1, 2, 1);
heatmap(cov_pre_Rest, 'Title', 'Pre-Stroke Rest');
subplot(1, 2, 2);
heatmap(cov_post_Rest, 'Title', 'Post-Stroke Rest');

% Pre-Stroke Hand Wave vs Post-Stroke Hand Wave
figure;
subplot(1, 2, 1);
heatmap(cov_pre_Wave, 'Title', 'Pre-Stroke Hand Wave');
subplot(1, 2, 2);
heatmap(cov_post_Wave, 'Title', 'Post-Stroke Hand Wave');

% Pre-Stroke Hand Clench vs Post-Stroke Hand Clench
figure;
subplot(1, 2, 1);
heatmap(cov_pre_Clench, 'Title', 'Pre-Stroke Hand Clench');
subplot(1, 2, 2);
heatmap(cov_post_Clench, 'Title', 'Post-Stroke Hand Clench');

% Pre-Stroke Face Rub vs Post-Stroke Face Rub
figure;
subplot(1, 2, 1);
heatmap(cov_pre_Rub, 'Title', 'Pre-Stroke Face Rub');
subplot(1, 2, 2);
heatmap(cov_post_Rub, 'Title', 'Post-Stroke Face Rub');

setClasses = ["Rest" "Hand Wave" "Hand Clench" "Face Rub"];

% 2D scatter plot of the initial untransformed matrix and features
scatterplot2D(pre_Rest, post_Rest,["LE" "F4" "C4" "P4" "P3" "C3" "F3"], 7,"Rest action", "reef");
scatterplot2D(pre_Wave, post_Wave,["LE" "F4" "C4" "P4" "P3" "C3" "F3"], 7,"Hand wave action", "meadow");
scatterplot2D(pre_Clench, post_Clench,["LE" "F4" "C4" "P4" "P3" "C3" "F3"], 7,"Hand clench action", "dye");
scatterplot2D(pre_Rub, post_Rub,["LE" "F4" "C4" "P4" "P3" "C3" "F3"], 7,"Face Rub action", "earth");

% Functions
% ----------------------------------------------------------------------
% 2D Scatter plot function; similar to the plot triangles from HW2Part0.
function scatterplot2D(preSet, postSet, setNames, nfeatures, titleString, colours)
    figure('Name', titleString);
    colororder(colours)

    % Create tile layout
    tiledlayout(nfeatures-1,nfeatures-1,'TileSpacing','compact','Padding','compact')
    
    % Convert to numeric and remove class field
    preSet = table2array(removevars(preSet,{'Comments'})); 
    postSet = table2array(removevars(postSet,{'Comments'})); 
    
    % standardise data
    preSet = standardized_data(preSet);
    postSet = standardized_data(postSet);

    % Iterate through tile layout and plot each measure with every other,
    % without redundancies
    for n = nfeatures-1 : -1 : 1
        for m = nfeatures : -1 : 2

            if (m >= n + 1)
                nexttile(((nfeatures-1-n)*(nfeatures-1)) + (nfeatures+1-m))
                

                % Plot for pre & post stroke
                scatter(preSet(:,m), preSet(:,n), 'o'); 
                hold on 
                scatter(postSet(:,m), postSet(:,n),'o'); 

                % Title plots with what is compared to what
                title(strcat(setNames(:,n)," against ",setNames(:,m)));
                hold off 

                % Remove axis for plots not at the edges to reduce clutter
                if ((m ~= nfeatures) && (n ~= 1))
                    set(gca,'XTick',[], 'YTick', [])
                elseif ((m == nfeatures) && (n ~= 1))
                    set(gca,'XTick',[])
                elseif ((m ~= nfeatures) && (n == 1))
                    set(gca,'YTick',[])
                end

            end


        end
    end


    % Set legend
    legend('prestroke','poststroke'); 
end

% Data standardisation/normalisation function
function b = standardized_data(data)
        data = data;
        datamean = mean(data);
        datastd = std(data);
        
        % Calculate the discriminant score
        b = (data - datamean) ./ datastd;
end

