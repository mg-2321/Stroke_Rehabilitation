prestroke = readtable("Sunjil_(Sunjil_Source)_prestrokeEEG_wavefistrub_10-7_test1_filtered.csv");
poststroke = readtable("Sunjil_(Ashreya_Source)_ADJUSTED_poststroke_EEG_S1_filtered.csv");

prestrokeMatthews = readtable("ProfMatthew_(Arsheya_source)_Prestoke_Redo.csv")
poststrokeMatthews = readtable("ProfMatthew_(Sunjil_source)_Poststoke_Redo.csv")
stroke = prestrokeMatthews;

% Split datasets by class
Rest = stroke(find(stroke.Comments=="Rest"), :);
Wave = stroke(find(stroke.Comments=="Hand Wave"), :);
Clench = stroke(find(stroke.Comments=="Hand Clench"), :);
Rub = stroke(find(stroke.Comments=="Face Rub"), :);


Ur_Rest = plotAllPCA(Rest, true);
Ur_Wave = plotAllPCA(Wave, true);
Ur_Clench = plotAllPCA(Clench, true);
Ur_Rub = plotAllPCA(Rub, true);

Ur_stroke = plotAllPCA(stroke, false);


% Putting class data into lists to plot in a single function
Ur_Set = {Ur_Rest, Ur_Wave, Ur_Clench, Ur_Rub};

PC_Set = ["PC1" "PC2" "PC3" "PC4"];
scatterplotsall(Ur_Set, PC_Set);

% Functions
% ----------------------------------------------------------------------
% Perform all PCA related functions and plot the according screen & loading
% vectors at once, given some dataset
function Ur = plotAllPCA(stroke_raw, dontPlot)

    % Preprocess data; Remove "useless" fields and rows
    stroke_data = rmmissing(stroke_raw);
    stroke_data = removevars(stroke_data, {'Time', 'Trigger', 'Time_Offset', 'ADC_Status', 'ADC_Sequence', 'Event','Comments'}); 
    
    % Convert the table to numeric array for covariance calculation
    stroke_numeric = table2array(stroke_data);
    

    % Standardise
    stroke_numeric = standardized_data(stroke_numeric);
    % stroke_data = minmaxnorm(stroke_data);

    

    % Intialise randomisers with a seed
    randseed = 12345;
    rng(randseed);
    
    
    % Randomise sets
    stroke_rand = stroke_numeric(randperm(length(stroke_numeric)),:);
    
    
    % PCA function; gives us our matrix X
    [X means vars covs] = PCAfunc(stroke_rand);
    
    
    % SVD function; Gives us values for U, S, V & Ur (Regular Scores matrix, calculated U*S)
    [U S V Ur] = SVDfunc(X, 7);
    
    if (~dontPlot)
        % Scree plots, analysing the information contribution of the PCs
        screePlots(S, 7);
        
        % Loading vectors plots, with only the most important features
        loadingVectors(V,7,7);
    end
end

% Plot all scatterplots at once, given some set of Ur matrices and the
% desired number of P
function scatterplotsall(Ur_Set, PC_Set)
    % 2D scatter plots
    scatterplot2D(Ur_Set,PC_Set, 4);
    
    % 3D scatter plots
    scatterplot3D(Ur_Set,PC_Set, 4);
end

% Basic PCA process script ; base code obtained from class sharepoint
function [X means vars covs] = PCAfunc(yourCoefficientMatrix)
   [nrows, ncols] = size(yourCoefficientMatrix); 
    X = zeros([nrows,ncols]); 
     
    means = mean(yourCoefficientMatrix);    
    vars = var(yourCoefficientMatrix); 
    stdevs = std(yourCoefficientMatrix); 
    covs = cov(yourCoefficientMatrix);

    % Mean center data 
    % This is necessary so that everything is mean centered at 0 
    % facilitates statistical and hypothesis analysis 
    % This bit is the normalisation part
    for i=1:ncols 
        for j=1:nrows 
            X(j,i) = -( means(:,i) - yourCoefficientMatrix(j,i)); 
        end 
    end 
     mean(X)  ;
     
    % 
    % Scale data 
    % This is necessary so that all data has the same order, e.g.,  
    % should not compare values in the thousands vs. values between 0 and 1 
    for i=1:ncols 
        for j=1:nrows 
            X(j,i) = X(j,i) / stdevs(:,i);   
        end 
    end         
     var(X) ;
end

% SVD function; base code obtained from class sharepoint
function [U S V Ur] = SVDfunc(X, nfeatures)
    % X is the original dataset 
    % Ur will be the transformed dataset  
    % S is covariance matrix (not normalized) 
    
    [U S V] = svd(X,0); 
    Ur = U*S;
     
    % Number of features to use 
    f_to_use = nfeatures;      
    feature_vector = 1:f_to_use; 
     
    r = Ur;  % make a copy of Ur to preserve it,  we will randomize r  
end

% Scree plots function; base code obtained from class sharepoint
function screePlots(S, nfeatures)
    % 
    % Obtain the necessary information for Scree Plots 
    % Obtain S^2 (and can also use to normalize S)   
    % 
    S2 = S^2; 
    weights2 = zeros(nfeatures,1); 
    sumS2 = sum(sum(S2)); 
    weightsum2 = 0; 
     
    for i=1:nfeatures 
        weights2(i) = S2(i,i)/sumS2; 
        weightsum2 = weightsum2 + weights2(i); 
        weight_c2(i) = weightsum2; 
    end 
     
    % Plotting Scree Plots 
    figure; 
    hold on
    plot(weights2,'x:b'); 
    plot(weight_c2,'x:r'); 
    grid; 
    title('Scree Plots'); 
    legend('Scree Plot', 'Scree Plot Cumulative'); 
end

% Loading vector plot function; base code obtained from class sharepoint
function loadingVectors(V,nfeatures, nvectors)
    for i=1:nfeatures 
        for j=1:nfeatures 
            Vsquare(i,j) = V(i,j)^2; 
            if V(i,j)<0 
                Vsquare(i,j) = Vsquare(i,j)*-1; 
            else  
                Vsquare(i,j) = Vsquare(i,j)*1; 
            end 
        end 
    end 
    
    figure;
    tiledlayout(1,nvectors,'TileSpacing','compact','Padding','compact')
    
    for  n = 1 : nvectors
        nexttile
        bar(Vsquare(:,n),0.5); 
        grid; 
        ymin = min(Vsquare(:,n)) + (min(Vsquare(:,n))/10); 
        ymax = max(Vsquare(:,n)) + (max(Vsquare(:,n))/10); 
        axis([0 nfeatures ymin ymax]); 
        xlabel('Feature index'); 
        ylabel('Importance of feature'); 
        [chart_title, ERRMSG] = sprintf('Loading Vector %d',n); 
        title(chart_title); 
    end
end

% 2D Scatter plot function; similar to the plot triangles from HW2Part0.
% Plotting on the heaviest PCs
function scatterplot2D(UrSet, setNames, nfeatures)
figure;
% Create tile layout
    tiledlayout(nfeatures-1,nfeatures-1,'TileSpacing','compact','Padding','compact')
    
    % Iterate through tile layout and plot each measure with every other,
    % without redundancies
    for n = nfeatures-1 : -1 : 1
        for m = nfeatures : -1 : 2
            
            if (m >= n + 1)
                nexttile(((nfeatures-1-n)*(nfeatures-1)) + (nfeatures+1-m))
                hold on 
    
                % Plot for United states, Australia & India
                for x = 1: size(UrSet,2)
                    Ur = UrSet{x};
                    scatter(Ur(:,m), Ur(:,n), '*'); 
                end

                
                % Title plots with what is compared to what
                title(strcat(setNames(:,n)," against ",setNames(:,m)));
                hold off 

                % Remove axis for plots not at the edges to reduce clutter
                if ((m ~= nfeatures) && (n ~= 1))
                    set(gca,'XTick',[], 'YTick', [])
                elseif ((m == nfeatures) && (n ~= 1))
                    set(gca,'XTick',[])
                elseif ((m ~= nfeatures) && (n == 1))
                    set(gca,'YTick',[])
                end
            end
        end
    end
    
    % Set legend
    legend('Rest', 'Wave', 'Clench','Rub'); 
end

% 3D Scatter plot function
% Plotting on the heaviest PCs
function scatterplot3D(UrSet, setNames, nfeatures)
figure;
    % Create tile layout
    tiledlayout(nfeatures-2,nfeatures-2,'TileSpacing','compact','Padding','compact')
    
    % Iterate through tile layout and plot each measure with every other,
    % without redundancies
    for n = nfeatures-2 : -1 : 1
        for m = nfeatures-1 : -1 : 2
            for l = nfeatures : -1 : 3
                
                if ((m >= n + 1) && (l >= m + 1))
                    nexttile
                    hold on 
        
                    % Plot for United states, Australia & India
                    for x = 1: size(UrSet,2)
                        Ur = UrSet{x};
                        scatter3(Ur(:,m), Ur(:,n), Ur(:,l) , '*'); 
                    end
                    view(40,35)
        
                    % Title axis
                    xlabel(setNames(:,m))
                    ylabel(setNames(:,n))
                    zlabel(setNames(:,l))

                    % Title plots with what is compared to what
                    title(strcat(setNames(:,n)," against ",setNames(:,m)," against ",setNames(:,l) ));
                    hold off 
                    
                 end
            end
        end
    end
    
    % Set legend
    legend('Rest', 'Wave', 'Clench','Rub'); 
end

% Data standardisation/normalisation function
function b = standardized_data(data)
        data = data;
        datamean = mean(data);
        datastd = std(data);
        
        % Calculate the discriminant score
        b = (data - datamean) ./ datastd;
end
